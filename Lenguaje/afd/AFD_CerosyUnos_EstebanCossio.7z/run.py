import Ceros_Unos as C

if __name__ == '__main__':
    # Lenguaje
    L = ['00011','0000111','101','11','11001010','1010011','10001010001']
    for i in range(len(L)):
        print(f'¿La secuencia {L[i]} es valida?: {C.reconocerSecuencia(L[i])}')

        ceros = L[i].count('0')
        unos = L[i].count('1')

        print(f'\nLa cantidad de ceros (0) es: {ceros}')
        print(f'La cantidad de unos (1) es: {unos}')
        print('\n==============================================================\n')

    while True:
        try:
            cadena = str(input('Ingrese una cadena: '))
        
        except EOFError:
            break

        #   El ciclo es infinito hasta que el usuario ingresa 0 0
        if(cadena == '0 0'):
            break

        print(f'¿La secuencia {cadena} es valida?: {C.reconocerSecuencia(cadena)}')

        ceros = cadena.count('0')
        unos = cadena.count('1')
        print(f'\nLa cantidad de ceros (0) es: {ceros}')
        print(f'La cantidad de unos (1) es: {unos}')
        print('\n==============================================================\n')